## Menu

Página Inicial
Sobre
Laptops
Smartphones
Contato

## Primeira Section

Boat Stone Bluetooth Speaker
Com dois núcleos principais de alta performance e 6 núcleos de baixo consumo de bateria que juntos, resultam em alto desempenho.
R$ 178,90\*
Comprar agora

-   valores no cartão de débito ou no PIX

## Segunda Section

Bluetooth 5.3
Desfrute de uma conectividade perfeita com a mais recente tecnologia
IPX5 À Prova D' Água
Estéreo sem fio verdadeiro
Portátil e leve

## Terceira Section

Leve sua música para qualquer lugar com este alto-lante compacto e leve
Perfeito para aventuras em movimento ou encontros improvisados.
